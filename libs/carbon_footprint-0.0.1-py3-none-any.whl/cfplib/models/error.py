from enum import Enum

class ERROR(Enum):
    E010 = {'status_code':422,'error_code':110, 'detail': 'json schema have less parameters that expected'}
    E020 = {'status_code':416,'error_code':120, 'detail': 'amount positive'}
    E030 = {'status_code':409,'error_code':130, 'detail': 'data file (marketer) not found'}
    E040 = {'status_code':410,'error_code':140, 'detail': 'data file (subcategory) not found'}
    E050 = {'status_code':411,'error_code':150, 'detail': 'nof found subcategory to calculate'}
    E060 = {'status_code':422,'error_code':160, 'detail': 'json schema are not correct some key are wrong'}
    E080 = {'status_code':506,'error_code':510, 'detail': 'division by zero'}
    E090 = {'status_code':506,'error_code':510, 'detail': 'error undetermined processing csv file'}

    