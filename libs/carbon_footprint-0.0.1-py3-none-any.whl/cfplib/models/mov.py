
class Mov:
    __title: str
    __amount: float
    __date: str
    __category: str
    __subcategory: str
    
    def __init__(self,title,amount,date,category,subcategory):
        self.__title = title
        self.__amount = amount
        self.__date = date
        self.__category = category
        self.__subcategory = subcategory
        
    def get_amount(self) -> float:
        return self.__amount
        
    def set_title(self,new_title:str) -> str :
        self.__title = new_title

    def get_category(self) -> str :
        return self.__category

    def get_subcategory(self) -> str :
        return self.__subcategory
    
    def get_title(self):
        return self.__title
    
    def clean_title(self, title: str) -> str :
        return title

