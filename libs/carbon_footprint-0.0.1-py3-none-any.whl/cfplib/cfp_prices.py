import csv
from csv import writer
import pandas as pd
import datetime


class CFP_PRICES:
    price: float

    def get_fuel_price(self):
        with open('./data/fuel_price.csv', "r") as scraped:
            last_date = scraped.readlines()[-1].split(',')[0].split('/')
        reverse_last_date = datetime.datetime.strptime(last_date[2]+'/'+last_date[1]+'/'+last_date[0], '%d/%m/%Y')
            
        fuel22 = pd.read_html('https://datosmacro.expansion.com/energia/precios-gasolina-diesel-calefaccion/espana')
        fuel22 = fuel22[0].drop([len(fuel22[0])-1],axis=0)
        df = pd.DataFrame(fuel22)        
        
        for index, row in df.iterrows():
            if datetime.datetime.strptime(row['Fecha'], '%d/%m/%Y') > reverse_last_date:
                super = float(row['Super 95'].replace(u'\xa0€','').replace(',','.'))
                diesel = float(row['Diesel'].replace(u'\xa0€','').replace(',','.'))
                price = round(float((super + diesel)/2),2)
                reverse_fecha = row['Fecha'].split('/')[2]+'/'+row['Fecha'].split('/')[1]+'/'+row['Fecha'].split('/')[0]
                new_price=[reverse_fecha,price]
    
                with open('./data/fuel_price.csv', 'a', newline='') as f_object:  
                    writer_object = writer(f_object)
                    writer_object.writerow(new_price)  
                    f_object.close()
       
        return reverse_last_date