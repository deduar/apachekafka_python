# Valiud subcategory valids and the factors
VALID_SUBCATEGORIES = [
    {'cat':'gasolineras','file':'data/fuel_price.csv','co2_factor':'2.35','ch4_factor':'8.4e-03','n2o_factor':'3.06e-05','h20_factor':'0','price':'0'},
    {'cat':'factura luz','file':'data/light_price.csv','co2_factor':'0.25','ch4_factor':'7.887e-05','n2o_factor':'1.058e-05','h20_factor':'0','price':'0'},
    {'cat':'factura gas','file':'data/gas_price.csv','co2_factor':'0.203','ch4_factor':'7.88e-05','n2o_factor':'0','h20_factor':'0','price':'0'},
    {'cat':'transporte privado','file':'','co2_factor':'0.11','ch4_factor':'0.0553936','n2o_factor':'0.03207','h20_factor':'0','price':'1.2'},
    {'cat':'transporte público y colectivo','file':'','co2_factor':'0.35','ch4_factor':'0.039132','n2o_factor':'0.0179463','h20_factor':'0','price':'0.15'},
    {'cat':'vuelos','file':'','co2_factor':'0.192','ch4_factor':'8.4532e-03','n2o_factor':'0.031812','h20_factor':'0','price':'0.05'},
    {'cat':'paquetería y mensajería','file':'0.158','co2_factor':'0.11','ch4_factor':'0.0221','n2o_factor':'7.8835e-03','h20_factor':'0','price':'1.35'},
    {'cat':'compra y alquiler','file':'','co2_factor':'8.78e-06','ch4_factor':'0','n2o_factor':'0','h20_factor':'0','price':'1'},
    {'cat':'renting','file':'','co2_factor':'8.78e-06','ch4_factor':'0','n2o_factor':'0','h20_factor':'0','price':'1'},
    {'cat':'factura basura','file':'','co2_factor':'1.48e-04','ch4_factor':'0','n2o_factor':'0','h20_factor':'0','price':'1'},
    {'cat':'gestorías, consultorías y asesorías','file':'','co2_factor':'5.23e-06','ch4_factor':'0','n2o_factor':'0','h20_factor':'0','price':'1'},
    {'cat':'telefonía e internet','file':'','co2_factor':'2.67e-06','ch4_factor':'0','n2o_factor':'0','h20_factor':'0','price':'1'},
    {'cat':'supermercados y grandes superficies','file':'','co2_factor':'0.37318','ch4_factor':'0','n2o_factor':'0','h20_factor':'0','price':'1'},
    {'cat':'moda y complementos','file':'','co2_factor':'0.54543','ch4_factor':'0','n2o_factor':'0','h20_factor':'0','price':'1'},
    {'cat':'restauración','file':'','co2_factor':'3.27e-05','ch4_factor':'0','n2o_factor':'0','h20_factor':'0','price':'1'},
    {'cat':'ocio nocturno','file':'','co2_factor':'3.27e-05','ch4_factor':'0','n2o_factor':'0','h20_factor':'0','price':'1'},
    {'cat':'alojamientos','file':'','co2_factor':'3.27e-05','ch4_factor':'0','n2o_factor':'0','h20_factor':'0','price':'1'},
    {'cat':'viajes','file':'','co2_factor':'0.11','ch4_factor':'0.013886859','n2o_factor':'0.025040484','h20_factor':'0','price':'0.1'},
    {'cat':'factura agua','file':'','co2_factor':'0','ch4_factor':'0','n2o_factor':'0','h20_factor':'1','price':'1.71'}
]

PLASTIC_CATEGORIES = ["compras"]

# fuzzywuzzy cut_off simillarity 
SCORE_CUTOFF = 0.65

# currente mov schema
MOV_SCHEMA = {
    'title': '',
    'amount': '',
    'date': '',
    'category': '',
    'subcategory': ''
}

MOV_SCHEMA_LENGHT = 5

CSV_IN_PATH = './data/csv_process/in/'
CSV_OUT_PATH = './data/csv_process/out/'

OUT_FIELDNAMES = ['id_user','date','category','subcategory','co2', 'ch4', 'n2o', 'h2o']