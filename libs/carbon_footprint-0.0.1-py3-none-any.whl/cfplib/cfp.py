import csv
import pandas as pd
from fuzzywuzzy import process
from datetime import datetime
from dateutil.relativedelta import relativedelta

from .config.cfp_config import PLASTIC_CATEGORIES, VALID_SUBCATEGORIES, SCORE_CUTOFF, MOV_SCHEMA, MOV_SCHEMA_LENGHT
from cfplib.models.mov import Mov
from cfplib.models.error import ERROR

class CFP:
    dic: dict
    
    def __init__(self,dic:dict) -> dict:
        self.dic = dic

    def estimateCFP(self):
        err = ERROR
        if len(self.dic) < MOV_SCHEMA_LENGHT:
            return {"co2":0,"ch4":0,"n2o":0,'h2o':0}
            return err.E010
        
        for key in MOV_SCHEMA.keys():
            if key not in self.dic.keys():
                return {"co2":0,"ch4":0,"n2o":0,'h2o':0}
                return err.E060
        
        mov = Mov(
            self.dic['title'],
            float(self.dic['amount'].replace(',','.')),
            self.dic['date'].replace('-','/'),
            self.dic['category'],
            self.dic['subcategory']
            )
        
        if mov.get_amount() > 0:
            return {"co2":0,"ch4":0,"n2o":0,'h2o':0, 'associated plastic':0}
            return err.E020

        plastic = 0
        
        if mov.get_category() in PLASTIC_CATEGORIES:
            if mov.get_amount() < -35:
                plastic = 5.78
            elif (mov.get_amount() >= -35) & (mov.get_amount()<= -20):
                plastic = -0.002*mov.get_amount()*0.25/0.00303
            elif (mov.get_amount() >= -20) & (mov.get_amount() < 0):
                plastic = -0.001*mov.get_amount()*0.25/0.00303

        
        for subcat in VALID_SUBCATEGORIES:
            if mov.get_subcategory() == subcat['cat']:
                try:
                    if self.dic['subcategory'] == 'factura gas' or self.dic['subcategory'] == 'gasolineras':
                        prices = pd.read_csv(subcat['file'])
                        prices['0'] = pd.to_datetime(prices['0'], format = "%Y/%m/%d")
                        price = prices[prices['0'] == self.dic['date']]['1'].values[0]

                    elif self.dic['subcategory'] == 'factura luz':
                            prices = pd.read_csv(subcat['file'])
                            prices['0'] = pd.to_datetime(prices['0'], format = "%Y/%m/%d")
                            date = pd.to_datetime(self.dic['date'], format = "%Y/%m/%d")
                            date1 = datetime(date.year, date.month, 1)- relativedelta(months=1)
                            date2 = datetime(date.year, date.month, 1)
                            price = ((31-date.day)*prices[prices['0'] == date1]['1'].values[0] + date.day*prices[prices['0'] == date2]['1'].values[0])/31
                            try:
                                file = open('./data/comercializadoras.csv')
                                csvreader = csv.reader(file)
                                comercializadora = process.extractOne(mov.get_title(), csvreader, score_cutoff=SCORE_CUTOFF)
                                if (comercializadora):
                                    subcat['co2_factor'] = float(comercializadora[0][1].replace(',','.'))
                                file.close()
                            except:
                                return {"co2":0,"ch4":0,"n2o":0,'h2o':0, 'associated plastic':plastic}
                                return err.E030  
                    else :
                        price = float(subcat['price'])
                    
                    try:
                        co2 = -mov.get_amount()/price * float(subcat['co2_factor'])
                        ch4 = co2 * float(subcat['ch4_factor'])
                        n2o = co2 * float(subcat['n2o_factor'])
                        if self.dic['subcategory'] == 'factura agua':
                            h2o = -mov.get_amount()/price * float(subcat['h20_factor'])
                        else:
                            h2o = float(0.0)
                        if self.dic['subcategory'] == '': 
                            return {"co2":0,"ch4":0,"n2o":0,'h2o':0, 'associated plastic':plastic}
                        return {"co2":co2,"ch4":ch4,"n2o":n2o,'h2o':h2o, 'associated plastic':plastic}
                    except:
                        return {"co2":0,"ch4":0,"n2o":0,'h2o':0, 'associated plastic':plastic}
                        return err.E080
                except:
                    return {"co2":0,"ch4":0,"n2o":0,'h2o':0, 'associated plastic':plastic}
                    return err.E040
                
        return {"co2":0,"ch4":0,"n2o":0,'h2o':0, 'associated plastic':plastic}    
        return err.E050


