import os
import csv
from datetime import date

from cfplib.cfp import CFP
from .config.cfp_config import CSV_IN_PATH, CSV_OUT_PATH, OUT_FIELDNAMES

class CFP_CSV:

    def csv_process(self):
        csv_inputs = os.listdir(CSV_IN_PATH) 
        
        today = date.today().strftime("%Y_%m_%d")
        
        cfp = []
        fieldnames = OUT_FIELDNAMES
        for csv_in in csv_inputs:                   # Open every file in dir
            in_file = open(CSV_IN_PATH+csv_in)
            csvreader = csv.reader(in_file)
            for row in csvreader:                   # Read every mov
                mov:dict = {
                    "title": row[1],
                    "amount": row[2],
                    "date": row[3],
                    "category": row[4],
                    "subcategory": row[5]
                }
                # cfp.append(CFP(mov).estimateCFP())
                est = CFP(mov).estimateCFP()
                cfp.append({'id_user':row[0],'date':row[3],'category':row[4],'subcategory':row[5],'co2':est['co2'],'ch4':est['ch4'],'n2o':est['n2o'],'h2o':est['h2o']})
            in_file.close
            
        with open(CSV_OUT_PATH+today+'.csv', 'w', encoding='UTF8', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(cfp)
    
        return(cfp)    
                
